import {useCallback, useEffect, useRef, useState} from 'react';
import {Activity, ArrowRight, ArrowUpRight, Bot, BriefcaseBusiness, Building2, Check, CircleAlert, ClipboardCheck, FileCheck2, GraduationCap, Mail, Square,
  Hexagon, Link2, LoaderCircle, MessageCircleQuestion, Plus, RefreshCw, Search, Send, Settings2, ShieldCheck, Sparkles, Table2, Users, X} from 'lucide-react';
import {ago, api, date, hasToken, initials, labels, Obj, pad, setToken} from './api';
import {Badge, Button, Empty, Glass, GlassButton, Progress} from './ui';
import {Profile} from './screens/Profile';
import {Companies} from './screens/Companies';
import {Settings} from './screens/Settings';
import {JobDetail} from './screens/JobDetail';
import {LogJob} from './screens/LogJob';
import {FindContacts} from './screens/FindContacts';

const NAV = [
  ['applications', 'Dashboard', BriefcaseBusiness],
  ['profile', 'Profile', GraduationCap],
  ['companies', 'Companies', Building2],
  ['settings', 'Settings', Settings2],
] as const;
const readMode = (): 'applier' | 'tracker' => {try {return localStorage.getItem('mode') === 'tracker' ? 'tracker' : 'applier';} catch {return 'applier';}};
// Time-of-day greeting for the dashboard heading; the name comes from the Identity section of profile.md.
const greeting = () => {const h = new Date().getHours(); return h < 5 ? 'Working late' : h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : h < 22 ? 'Good evening' : 'Working late';};
const PIPELINE = ['new', 'preparing', 'needs_attention', 'ready', 'approved', 'submitted', 'applied'];

export default function App() {
  const lastState = useRef('');
  const [state, setState] = useState<Obj | null>(null), [screen, setScreen] = useState('applications'), [filter, setFilter] = useState('all');
  const [mode, setModeState] = useState<'applier' | 'tracker'>(readMode);
  const setMode = (m: 'applier' | 'tracker') => {setModeState(m); try {localStorage.setItem('mode', m);} catch {}};
  const [query, setQuery] = useState(''), [selected, setSelected] = useState<string[]>([]), [detail, setDetail] = useState<string | null>(null);
  const [importOpen, setImportOpen] = useState(false), [logOpen, setLogOpen] = useState(false), [importMode, setImportMode] = useState(''), [contactsOpen, setContactsOpen] = useState(false), [links, setLinks] = useState(''), [busy, setBusy] = useState(''), [notice, setNotice] = useState(''), [error, setError] = useState('');
  // The dashboard polls every few seconds; only re-render when something actually changed.
  const refresh = useCallback(async () => {
    const next = await api('/state'), text = JSON.stringify(next);
    if (text !== lastState.current) {lastState.current = text; setState(next);}
  }, []);
  useEffect(() => {api('/bootstrap').then(b => {setToken(b.token); return refresh();}).catch(e => setError(e.message));}, [refresh]);
  // Poll every second while a job is running so its progress stays live; otherwise every few seconds.
  const running = !!state && (Object.keys(state.progress || {}).length > 0 || state.monitor?.running || state.batch_running);
  useEffect(() => {
    const id = setInterval(() => {if (hasToken()) refresh().catch(() => {});}, running ? 1000 : 3500);
    return () => clearInterval(id);
  }, [refresh, running]);
  async function run(name: string, action: () => Promise<any>, success?: string) {
    setBusy(name); setError('');
    try {const result = await action(); await refresh(); if (success) setNotice(success); return result;}
    catch (e: any) {setError(e.message);}
    finally {setBusy('');}
  }
  useEffect(() => {if (notice) {const id = setTimeout(() => setNotice(''), 6500); return () => clearTimeout(id);}}, [notice]);
  useEffect(() => {
    const esc = (e: KeyboardEvent) => {if (e.key === 'Escape') {setImportOpen(false); setLogOpen(false); setContactsOpen(false); setDetail(null);}};
    window.addEventListener('keydown', esc);
    return () => window.removeEventListener('keydown', esc);
  }, []);

  if (!state) return <div className="boot"><div className="boot-core"><Hexagon className="boot-mark"/><h2>Loading</h2>
    {error ? <p className="error-text">{error}</p> : <LoaderCircle className="spin"/>}</div></div>;

  const jobs: Obj[] = state.jobs;
  const counts = (s: string) => jobs.filter(j => j.status === s).length;
  const ready = jobs.filter(j => j.status === 'ready' || j.status === 'approved').length;
  const held = jobs.filter(j => j.referral_status === 'pending' && j.status !== 'submitted').length;
  const submitted = counts('submitted') + counts('applied');
  const attention = counts('needs_attention') + counts('uncertain');
  const action = jobs.filter(j => j.action_required).length;
  const filtered = jobs.filter(j => `${j.company} ${j.title}`.toLowerCase().includes(query.toLowerCase()) && (filter === 'all'
    || filter === 'review' && ['ready', 'approved', 'needs_attention'].includes(j.status)
    || filter === 'pending' && j.referral_status === 'pending'
    || filter === 'submitted' && ['submitted', 'applied'].includes(j.status)
    || filter === 'action' && j.action_required));
  const active = jobs.find(j => j.id === detail);
  const jobName = (id: string) => {const j = jobs.find(x => x.id === id); return j ? j.company || j.title : '';};
  const approveSelected = async () => {
    const approved = [];
    for (const id of selected) {
      let job = (await api('/state')).jobs.find((j: Obj) => j.id === id);
      if (job.status !== 'approved') job = await api(`/jobs/${id}/approve`, 'POST', {revision: job.revision});
      approved.push(job.id);
    }
    await api('/submit', 'POST', {ids: approved});
    setSelected([]);
  };
  const questions = [
    ...(state.companies || []).flatMap((c: Obj) => c.questions.filter((q: Obj) => !q.answer).map((q: Obj) => ({...q, company: c}))),
    ...jobs.filter(j => j.status === 'needs_attention' && j.package?.unresolved?.length).map(j => ({id: 'job-' + j.id, question: j.package.unresolved[0],
      suggested: j.package.suggested_answer || '', job: j, company: {name: j.company, id: j.company_id}})),
  ];
  const tracker = mode === 'tracker';
  const s = state.settings, caps = state.capabilities, last = state.last_inference;
  const aiOk = s.provider === 'ollama' || (s.provider === 'codex' ? caps.codex : caps.anthropic_key);
  const systems = [
    {label: 'AI', value: s.provider === 'codex' ? (caps.codex ? 'ChatGPT · Codex' : 'Install Codex') : s.provider === 'anthropic' ? (caps.anthropic_key ? s.model : 'Key needed') : s.model || 'Ollama', ok: aiOk},
    {label: 'Fallback', value: s.fallback_enabled ? 'Local ready' : 'Off', ok: s.fallback_enabled},
    {label: 'LaTeX', value: caps.latex ? 'Compiler' : 'Missing', ok: caps.latex},
    {label: 'Tracker', value: s.sheet_sync_enabled ? 'Synced' : 'Offline', ok: s.sheet_sync_enabled},
    {label: 'Last response', value: last ? `${last.fallback ? 'Local · ' : ''}${last.model}` : '—', ok: true, dim: true},
    {label: 'AI calls', value: (state.usage.calls || 0).toLocaleString(), ok: true, dim: true},
  ];
  const activity = [...Object.values(state.progress || {}).map((p: any) => p.stage), ...(state.monitor?.running ? ['Checking email'] : []), ...(state.batch_running ? ['Submitting'] : [])];

  return <div className="app">
    <Glass className="dock" radius={30} displacement={40} blur={0.12}>
      <div className="dock-body">
        <a className="brand" href="/" aria-label="JobApplier home"><img className="brand-mark" src="/favicon.svg" alt=""/><span>job<b>applier</b></span></a>
        <div className="mode-toggle" role="tablist" aria-label="Mode">
          <button role="tab" aria-selected={!tracker} className={!tracker ? 'on' : ''} onClick={() => setMode('applier')}><Bot size={14}/>AI Applier</button>
          <button role="tab" aria-selected={tracker} className={tracker ? 'on' : ''} onClick={() => setMode('tracker')}><Table2 size={14}/>Tracker</button>
        </div>
        <div className="dock-label">NAVIGATION</div>
        <nav>{NAV.map(([id, title, Icon]) => <button key={id} className={screen === id ? 'nav active' : 'nav'} onClick={() => setScreen(id)}
          aria-current={screen === id ? 'page' : undefined}><Icon size={18}/><span>{title}</span>
          {id === 'applications' && <em>{jobs.length}</em>}{id === 'profile' && !state.profile.verified && <i className="nav-dot" title="Profile not verified"/>}{id === 'companies' && questions.length > 0 && <em>{questions.length}</em>}</button>)}</nav>
        <div className="dock-foot">
          <div className="guard"><ShieldCheck size={18}/><div><strong>Approval required</strong><small>Nothing is submitted without your approval.</small></div></div>
          <div className="local"><span className="pulse"/>Local · 127.0.0.1</div>
        </div>
      </div>
    </Glass>

    <main className="main">
      <Glass className="commandbar" radius={22} displacement={32} blur={0.3}>
        <div className="commandbar-body">
          <div className="crumb"><span>{tracker ? 'TRACKER' : 'AI APPLIER'}</span><b>/</b>{NAV.find(n => n[0] === screen)?.[1]}</div>
          <div className="chips">{running && <span className="chip run"><i/>{activity.length} running · {activity[0]}</span>}</div>
          <div className="commandbar-actions">
            {running && <button className="btn stop" title="Stop every running operation" onClick={() => run('stop', async () => {const r = await api('/stop', 'POST'); setNotice(r.stopped ? `Stopped ${r.stopped} operation${r.stopped > 1 ? 's' : ''}.` : 'Nothing was running.');})}><Square size={13}/>Stop</button>}
            <button className="icon-btn" title={state.monitor?.last_run ? `Check email for employer replies (last: ${ago(state.monitor.last_run)})` : 'Check email for employer replies'} aria-label="Check email" disabled={!!busy || state.monitor?.running}
              onClick={() => run('monitor', async () => {const r = await api('/monitor/run', 'POST', {}); setNotice(`Email checked: ${r.checked} new message${r.checked === 1 ? '' : 's'}, ${r.updated} application${r.updated === 1 ? '' : 's'} updated.`);})}>
              <Mail size={16} className={busy === 'monitor' || state.monitor?.running ? 'spin' : ''}/></button>
            <button className="icon-btn" title="Refresh workspace" aria-label="Refresh workspace" onClick={() => run('refresh', refresh)}><RefreshCw size={16} className={busy === 'refresh' ? 'spin' : ''}/></button>
            {tracker && <button className="btn" disabled={!jobs.length} title="Find referral contacts for selected jobs" onClick={() => setContactsOpen(true)}><Users size={15}/>Find contacts</button>}
            {tracker ? <GlassButton className="cta" onClick={() => setLogOpen(true)} label="Log an application"><ClipboardCheck size={16}/>Log application</GlassButton>
              : <GlassButton className="cta" onClick={() => setImportOpen(true)} label="Add job links"><Plus size={16}/>Add job links</GlassButton>}
          </div>
        </div>
      </Glass>

      <div className="status-strip">{systems.map(x => <button key={x.label} className={'status-cell' + (x.dim ? ' dim' : x.ok ? ' ok' : ' warn')} onClick={() => setScreen('settings')} title="Open Settings"><span className="led"/><small>{x.label}</small><b>{x.value}</b></button>)}</div>
      {error && <div className="alert" role="alert"><CircleAlert size={18}/><span>{error}</span><button onClick={() => setError('')} aria-label="Dismiss error"><X size={15}/></button></div>}

      {screen === 'applications' && <div className="page">
        <div className="hero">
          <div><h1>{greeting()}{state.profile.identity?.first_name ? `, ${state.profile.identity.first_name}` : ''}.</h1>
            <p>{running ? `${Object.keys(state.progress).length} running · ` : ''}{questions.length ? `${questions.length} question${questions.length > 1 ? 's' : ''} waiting · ` : ''}{attention ? `${attention} need${attention > 1 ? '' : 's'} attention` : ready ? `${ready} ready for review` : tracker ? 'Jobs you apply to yourself, tracked in one place' : 'Add job links to get started'}</p></div>
        </div>

        <div className="stats">
          {[
            {label: 'Applications', n: jobs.length, sub: 'Total tracked', Icon: BriefcaseBusiness},
            tracker ? {label: 'Action required', n: action, sub: 'From employer replies', Icon: CircleAlert} : {label: 'Ready for review', n: ready, sub: 'Awaiting approval', Icon: FileCheck2},
            {label: 'Referral holds', n: held, sub: 'On hold', Icon: Users},
            {label: tracker ? 'Applied' : 'Submitted', n: submitted, sub: tracker ? 'Recorded applications' : 'Confirmed', Icon: Send},
          ].map(({label, n, sub, Icon}) => <div key={label} className="stat">
            <div className="stat-top"><span>{label}</span><Icon size={16}/></div><strong>{pad(n)}</strong><small>{sub}</small>
          </div>)}
        </div>

        <div className="pipeline" aria-label="Pipeline by status">
          <div className="pipeline-bar">{PIPELINE.map(st => {const n = counts(st); return n ? <span key={st} className={'seg s-' + st} style={{flex: n}} title={`${labels[st]}: ${n}`}/> : null;})}
            {!jobs.length && <span className="seg s-empty" style={{flex: 1}}/>}</div>
          <div className="pipeline-legend">{PIPELINE.map(st => <span key={st} className={'s-' + st}><i/>{labels[st]}<b>{counts(st)}</b></span>)}</div>
        </div>

        {!state.profile.verified && <button className="setup" onClick={() => setScreen('profile')}><span className="setup-orb"><Sparkles size={20}/></span>
          <span><strong>Complete your profile</strong><small>Upload your documents and verify your details before preparing applications.</small></span><ArrowRight size={18}/></button>}

        <div className="board-grid">
          <section className="panel board">
            <header className="panel-head"><div><h2>Applications <span className="count">{jobs.length}</span></h2><p>{tracker ? 'Everything you have applied to, with replies and referrals.' : 'Select applications that are ready to approve and submit them together.'}</p></div>
              <button className="link-chip" onClick={() => setScreen('sheets')}><Table2 size={14}/>{s.sheet_sync_enabled ? 'Tracker connected' : 'Connect tracker'}<ArrowUpRight size={13}/></button></header>
            <div className="toolbar">
              <div className="segmented">{(tracker ? [['all', 'All'], ['submitted', 'Applied'], ['pending', 'Referrals'], ['action', 'Action required']] : [['all', 'All'], ['review', 'To review'], ['pending', 'Referrals'], ['submitted', 'Submitted']]).map(([v, t]) =>
                <button key={v} onClick={() => setFilter(v)} className={filter === v ? 'on' : ''}>{t}</button>)}</div>
              <label className="search"><Search size={15}/><input placeholder="Search" aria-label="Search opportunities" value={query} onChange={e => setQuery(e.target.value)}/></label>
            </div>
            {selected.length > 0 && <div className="selection"><span>{selected.length} selected</span>
              <Button primary disabled={!!busy} onClick={() => run('submit', approveSelected, 'Approved applications have entered the submission queue.')}><Send size={14}/>Approve & submit</Button>
              <button className="text-btn" onClick={() => setSelected([])}>Clear</button></div>}
            {filtered.length === 0 ? <Empty title={jobs.length ? 'No matches' : 'No applications yet'}>{jobs.length ? 'Try another search or filter.' : 'Add job links to get started.'}</Empty>
              : <div className="rows">{filtered.map(j => {
                const selectable = ['ready', 'approved'].includes(j.status) && j.referral_status !== 'pending';
                return <div className="row" key={j.id} role="button" tabIndex={0} onClick={() => setDetail(j.id)} onKeyDown={e => {if (e.key === 'Enter') setDetail(j.id);}}>
                  <span className="row-check" onClick={e => e.stopPropagation()}>{!tracker && <input type="checkbox" aria-label={`Select ${j.title}`} disabled={!selectable}
                    checked={selected.includes(j.id)} onChange={e => setSelected(e.target.checked ? [...selected, j.id] : selected.filter(x => x !== j.id))}/>}</span>
                  <span className="logo">{initials(j.company)}</span>
                  <span className="row-main"><strong>{j.title || 'Reading posting…'}{j.mode === 'autonomous' && <span className="tag auto" title="Autonomous: submits without review">auto</span>}</strong><small>{j.company}{j.location && <> · {j.location}</>}{j.posting_kind === 'expression_of_interest' && ' · Expression of interest'}</small></span>
                  {state.progress?.[j.id] ? <Progress p={state.progress[j.id]} compact/> : <Badge status={j.status}/>}
                  <span className="row-ref">{j.referral_status === 'pending' ? <span className="tag amber"><Users size={12}/>Hold</span> : j.referral_status === 'received' ? <span className="tag green">Referral</span> : j.contact_profile_url ? <span className="tag" title="A referral contact was found">Contact</span> : <span className="muted">—</span>}</span>
                  <span className="row-date" title={tracker ? 'Date applied' : 'Date added'}>{date(tracker ? (j.submitted_at || j.created_at) : j.created_at)}</span>
                  <ArrowUpRight size={16} className="row-go"/>
                </div>;
              })}</div>}
            <footer className="board-foot"><span><ShieldCheck size={13}/>{tracker ? 'Synced to your tracker sheet after every change.' : 'Submissions require your approval.'}</span><span>{filtered.length} shown</span></footer>
          </section>

          <aside className="side">
            {jobs.some(j => j.action_required) && <section className="panel actions">
              <header className="panel-head"><div><h2><CircleAlert size={16}/>Action required</h2><p>From employer emails.</p></div></header>
              {jobs.filter(j => j.action_required).map(j => <div className="question" key={j.id}>
                <small>{j.company} · {j.title}</small><strong>{j.action_required.message}</strong>
                <div className="row-actions" style={{marginTop: 4}}>{j.action_required.link && <a className="link-chip" href={j.action_required.link} target="_blank" rel="noreferrer">Open email <ArrowUpRight size={12}/></a>}
                  <button className="text-btn" onClick={() => setDetail(j.id)}>Open application</button>
                  <button className="text-btn" onClick={() => run('done', () => api(`/jobs/${j.id}/action-done`, 'POST'))}>Done</button></div>
              </div>)}
            </section>}
            {questions.length > 0 && <section className="panel questions">
              <header className="panel-head"><div><h2><MessageCircleQuestion size={16}/>Questions</h2><p>Answered once per company, reused everywhere.</p></div></header>
              {questions.slice(0, 6).map((q: Obj) => <QuestionRow key={q.id} q={q} run={run} busy={busy}/>)}
              {questions.length > 6 && <button className="text-btn" onClick={() => setScreen('companies')}>{questions.length - 6} more on the Companies page</button>}
            </section>}
            <section className="panel feed">
              <header className="panel-head"><div><h2><Activity size={16}/>Log</h2></div></header>
              {state.events.length === 0 ? <p className="muted small">No activity yet.</p>
                : <ol>{state.events.slice(0, 14).map((e: Obj) => <li key={e.id} onClick={() => e.job_id && setDetail(e.job_id)} className={e.job_id ? 'linked' : ''}>
                  <i/><div><p>{e.message}</p><small>{e.job_id && jobName(e.job_id) ? jobName(e.job_id) + ' · ' : ''}{ago(e.at)}</small></div></li>)}</ol>}
            </section>
          </aside>
        </div>
      </div>}
      {screen === 'profile' && <Profile state={state} run={run} busy={busy}/>}
      {screen === 'companies' && <Companies state={state} run={run} busy={busy} openJob={id => setDetail(id)}/>}
      {screen === 'settings' && <Settings state={state} run={run} busy={busy}/>}
    </main>

    {notice && <div className="toast" role="status"><Check size={16}/>{notice}<button onClick={() => setNotice('')} aria-label="Dismiss notification"><X size={14}/></button></div>}

    {importOpen && <div className="overlay" onClick={() => setImportOpen(false)}><div className="modal" role="dialog" aria-modal="true" aria-label="Add job links" onClick={e => e.stopPropagation()}>
      <button className="icon-btn close" onClick={() => setImportOpen(false)} aria-label="Close"><X size={18}/></button>
      <span className="modal-orb"><Link2 size={22}/></span><h2>Add job links</h2>
      <p>Paste one or more job links, one per line. Duplicates are skipped.</p>
      <div className="mode-pick three">{[['advisor', 'Advisor', 'Tailored skills, cover letter and answers. You apply yourself.'], ['assisted', 'AI Applier', 'Tailors your resume, fills the form, waits for your approval, then submits.'], ['autonomous', 'Autonomous', 'Same, but submits without review. Skills only; anything uncertain is parked for you.']].map(([v, t, d]) =>
        <label key={v} className={'mode-opt' + ((importMode || s.default_mode) === v ? ' on' : '')}><input type="radio" name="mode" checked={(importMode || s.default_mode) === v} onChange={() => setImportMode(v)}/><strong>{t}</strong><small>{d}</small></label>)}</div>
      <textarea autoFocus rows={8} value={links} onChange={e => setLinks(e.target.value)} placeholder={'https://company.com/careers/job/…\nhttps://job-boards.greenhouse.io/…'}/>
      <div className="modal-foot"><span className="muted small">{links.split(/\s+/).filter(Boolean).length} link(s)</span>
        <div><Button onClick={() => setImportOpen(false)}>Cancel</Button>
          <Button primary disabled={!links.trim() || !!busy} onClick={() => run('import', async () => {
            const r = await api('/jobs', 'POST', {urls: links.split(/\s+/).filter(Boolean), mode: importMode || s.default_mode});
            if (r.errors.length) throw new Error(`${r.imported.length} added. ${r.errors.map((e: Obj) => e.error).join(' ')}`);
            setLinks(''); setImportOpen(false);
          }, 'Jobs added.')}><Plus size={15}/>Add</Button></div></div>
    </div></div>}
    {logOpen && <LogJob close={() => setLogOpen(false)} run={run} busy={busy}/>}
    {contactsOpen && <FindContacts jobs={selected.length ? jobs.filter(j => selected.includes(j.id)) : jobs} close={() => setContactsOpen(false)} run={run} busy={busy}/>}
    {active && <JobDetail job={active} state={state} close={() => setDetail(null)} run={run} busy={busy} goProfile={() => {setDetail(null); setScreen('profile');}}/>}
  </div>;
}


function QuestionRow({q, run, busy}: {q: Obj, run: (n: string, a: () => Promise<any>, s?: string) => Promise<any>, busy: string}) {
  const [v, setV] = useState('');
  const answer = (value: string) => q.job
    ? run('answer', () => api(`/jobs/${q.job.id}/answer`, 'POST', {answer: value}), 'Answer saved to your profile. Resume the application when ready.')
    : run('answer', () => api(`/companies/${q.company.id}/questions/${q.id}`, 'POST', {answer: value}), 'Answer saved.');
  useEffect(() => {if (q.suggested && !v) setV(q.suggested);}, [q.suggested]);
  return <div className="question">
    <small>{q.company.name}{q.job ? ` · ${q.job.title}` : ''}</small><strong>{q.question}</strong>
    {q.suggested && <span className="muted small">Suggested from your profile — check it before saving.</span>}
    {q.choices?.length > 0 ? <div className="choices">{q.choices.map((c: string) => <button key={c} className="btn" disabled={!!busy} onClick={() => answer(c)}>{c}</button>)}</div>
    : <div className="inline-form"><input placeholder="Answer" value={v} onChange={e => setV(e.target.value)} onKeyDown={e => {if (e.key === 'Enter' && v.trim()) run('answer', () => api(`/companies/${q.company.id}/questions/${q.id}`, 'POST', {answer: v}), 'Answer saved.');}}/>
      <Button disabled={!v.trim() || !!busy} onClick={() => answer(v)}>Save</Button></div>}
  </div>;
}
