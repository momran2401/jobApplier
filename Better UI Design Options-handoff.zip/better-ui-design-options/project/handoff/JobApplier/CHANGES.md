# JobApplier — logo, favicon, greeting

Unzip over your `JobApplier/` folder (same paths), then rebuild:

```sh
cd frontend && npm run build
```

## Files
- `frontend/public/favicon.svg` — new 2c "Folio" mark (also used as the sidebar logo)
- `frontend/public/favicon-32.png`, `frontend/public/apple-touch-icon.png` — PNG fallbacks
- `frontend/index.html` — favicon + apple-touch-icon links
- `frontend/src/App.tsx`
  - sidebar brand: `<Hexagon>` tile → `<img className="brand-mark" src="/favicon.svg">`
  - dashboard heading: "Dashboard" → "Good evening, Mustafa." (time of day + `profile.identity.first_name`)
  - Activity panel title → "Log"
- `frontend/src/style.css` — one rule: `img.brand-mark` (keeps the 32px rounded tile, drops the old background)

Vite copies `public/` into `dist/`, which FastAPI already serves at `/`, so `/favicon.svg` resolves with no backend change.

## Not included yet
The full 1a "Morning Paper" restyle: top nav, Newsreader/Geist type, warm palette, three-column day view. It's in `Redesign Options.dc.html#1a`, ready to port to `App.tsx` + `style.css` next.
