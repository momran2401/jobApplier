// <ja-icon name="hexagon" size="16"> — inlines a Lucide SVG from ./icons so it inherits currentColor.
(() => {
  if (customElements.get('ja-icon')) return;
  const base = new URL('icons/', document.currentScript ? document.currentScript.src : location.href).href;
  const cache = {};
  const load = n => cache[n] || (cache[n] = fetch(base + n + '.svg').then(r => r.ok ? r.text() : '').catch(() => ''));
  customElements.define('ja-icon', class extends HTMLElement {
    static get observedAttributes() { return ['name', 'size', 'stroke']; }
    connectedCallback() { this.render(); }
    attributeChangedCallback() { if (this.isConnected) this.render(); }
    async render() {
      const n = this.getAttribute('name'), s = this.getAttribute('size') || '16';
      if (!n) return;
      const svg = await load(n);
      if (this.getAttribute('name') !== n) return;
      this.innerHTML = svg.replace('<svg', `<svg style="width:${s}px;height:${s}px;display:block;flex:none"`).replace(/stroke-width="2"/, `stroke-width="${this.getAttribute('stroke') || 2}"`);
    }
  });
})();
